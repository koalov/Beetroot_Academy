with open('myfile.txt', 'w')as f:
    f.write('Hello file world!')
