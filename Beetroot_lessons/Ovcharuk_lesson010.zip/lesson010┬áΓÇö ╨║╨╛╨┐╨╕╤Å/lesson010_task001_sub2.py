with open('myfile.txt') as f:
    content = f.read()

print(content)
