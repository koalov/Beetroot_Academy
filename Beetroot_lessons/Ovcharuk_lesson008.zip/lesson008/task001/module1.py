from module2 import fib

variable = fib(60)
print(variable)

print(fib(int(input('Enter the number of Fibonacci sequence, You want to find: '))))
