s1 = '#' * 9
s2 = '#\t\t#'
print(f'{s1}\n{s2}\n{s2}\n{s2}\n{s1}\n\n{s2}\n{s2}\n{s1}\n{s2}\n{s2}')
