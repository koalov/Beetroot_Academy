my_string = input('Enter anything: ')
print(f'You print: {my_string}')
