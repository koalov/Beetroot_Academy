"""A simple function.

Create a simple function called favorite_movie, which takes a string containing the
name of your favorite movie. The function should then print “My favorite movie is
named {name}”."""


def favourite_movie(name):
    print(f'My favorite movie is named "{name}"')


favourite_movie('The Matrix')
favourite_movie('The Shawshank Redemption')
favourite_movie('Interstate 60')
favourite_movie('Limitless')
