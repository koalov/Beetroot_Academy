name = 'Kostyantyn'
surname = 'Ovcharuk'
print('Hello, Mr. {} {}! Welcome!'.format(name, surname))
